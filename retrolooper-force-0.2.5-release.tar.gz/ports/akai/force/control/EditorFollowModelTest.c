// Copyright (c) 2026 IAMTHEBAND LLC, Retroloop USA.
// SPDX-License-Identifier: GPL-3.0-only
#define main legacy_editor_model_main
#include "EditorTrackModelTest.c"
#undef main
static uint32_t effects_manager[32],queues[64];
static unsigned opens,closes;
static void open_editor(uint32_t manager,uint32_t iface,uint32_t slot,uint32_t native_mode){
 assert(manager==(uintptr_t)effects_manager&&native_mode==(uintptr_t)mode);
 unsigned pg=iface==(uintptr_t)program[0]+0x3c?0:1;assert(iface==(uintptr_t)program[pg]+0x3c);
 assert(native_word((uintptr_t)project+0xa0)==(uintptr_t)track[pg]);
 ++opens;show(pg,slot);
}
static void close_editor(uint32_t native_mode,unsigned option,unsigned popup){assert(native_mode==(uintptr_t)mode&&option==0&&popup==0x30fa);++closes;put(mode,0x6c,0x3080);}
static void begin(void){
 native_mem=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);assert(native_mem>=0);native_supported=native_enabled=1;
 native_queues=(uintptr_t)queues;test_editor_application=(uintptr_t)app;test_editor_select=select_track;
 memset(&last_editor_owner,0,sizeof last_editor_owner);force_last_selected=force_follow_target=force_follow_effect=0;
 opens=closes=selections=force_editor_switches=force_editor_closes=0;visible_editor_fx=visible_editor_open=0;
 put(project,0x94,1);put(project,0xa0,(uintptr_t)track[0]);put(pool,0x64,(uintptr_t)(tracks+2));
 put(track[0],0x64c,6);put(track[1],0x64c,6);put(program[0],0x3c,0x6d4b81c);put(program[1],0x3c,0x6d4b81c);
 test_force_editor_open=open_editor;test_force_editor_close=close_editor;
 put(effects_manager,0,0x6cb6dfc);put(effects_manager,0xc,native_queues);put(effects_manager,0x18,(uintptr_t)session);
 put(editor,0x1f8,(uintptr_t)mode);put(editor,0x1fc,(uintptr_t)effects_manager);
 put(mode,0x40,0x2083);((unsigned char*)editor)[8+0x68]=2;show(0,0);ui_refresh();pad_refresh_context();
 assert(visible_editor_fx==(uintptr_t)fx[0]&&pad_owner(fx[0])&&selections==0);
}
int main(void){
 assert(legacy_editor_model_main()==0);begin();
 put(project,0xa0,(uintptr_t)track[1]);ui_refresh();pad_refresh_context();
 assert(opens==1&&selections==0&&visible_editor_fx==(uintptr_t)fx[1]&&pad_owner(fx[1])&&!pad_owner(fx[0]));
 assert(native_word((uintptr_t)program[0]+0x26f0)==0&&native_word((uintptr_t)program[1]+0x26f0)==1);
 for(unsigned i=0;i<8;++i)ui_refresh();assert(opens==1&&selections==0);
 for(unsigned i=0;i<10;++i){unsigned n=i%2;put(project,0xa0,(uintptr_t)track[n]);ui_refresh();pad_refresh_context();assert(visible_editor_fx==(uintptr_t)fx[n]&&pad_owner(fx[n])&&selections==0);}
 assert(opens==11);
 /* Explicitly opening another instance retains owner-selection behaviour. */
 show(0,0);ui_refresh();assert(selections==1&&native_word((uintptr_t)project+0xa0)==(uintptr_t)track[0]);
 /* A second insert is retained by slot where available; fallback is first. */
 show(1,1);ui_refresh();assert(selections==2&&visible_editor_fx==(uintptr_t)fx[2]);
 put(project,0xa0,(uintptr_t)track[0]);ui_refresh();assert(visible_editor_fx==(uintptr_t)fx[0]);
 put(project,0xa0,(uintptr_t)track[1]);ui_refresh();assert(visible_editor_fx==(uintptr_t)fx[1]);
 /* Selecting a track without this looper closes the editor; pads return native. */
 tracks[2]=(uintptr_t)track[2];put(track[2],0,0x6d50644);put(track[2],0x64c,3);put(pool,0x64,(uintptr_t)(tracks+3));
 put(project,0xa0,(uintptr_t)track[2]);ui_refresh();pad_refresh_context();assert(closes==1&&!visible_editor_open&&!visible_editor_fx&&!pad_owner(fx[0])&&!pad_owner(fx[1]));
 close(native_mem);begin();
 /* Broken links and deleted/ambiguous owners never call native code. */
 put(effects_manager,0x18,0);put(project,0xa0,(uintptr_t)track[1]);ui_refresh();assert(opens==0&&selections==0&&!visible_editor_fx);put(effects_manager,0x18,(uintptr_t)session);
 put(project,0xa0,(uintptr_t)track[0]);ui_refresh();put(pool,0x64,(uintptr_t)(tracks+1));put(project,0xa0,(uintptr_t)track[1]);ui_refresh();assert(opens==0&&!visible_editor_fx);put(pool,0x64,(uintptr_t)(tracks+2));
 put(project,0xa0,(uintptr_t)track[0]);ui_refresh();put(mode,0x40,0x208d);put(project,0xa0,(uintptr_t)track[1]);ui_refresh();assert(opens==0&&!visible_editor_fx);
 close(native_mem);unlink(RLO_TRACK_STATE_PATH);
 dprintf(2,"PASS: Force track buttons retarget the visible looper and pad owner, no selection fights or repeated opens, rapid switches, native monitor handoff, explicit editor owner selection, second-slot fallback, no-looper close, invalid manager/deleted owner rejection and native-mode protection\n");return 0;
}
