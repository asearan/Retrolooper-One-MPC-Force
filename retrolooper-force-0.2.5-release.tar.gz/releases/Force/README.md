# Retrolooper One 0.2.5 — Force

Bounce a recorded loop into a Matrix clip on the looper's Audio track. Stop Force, tap **TO CLIP**, choose a Matrix slot, then reopen that looper and tap **BOUNCE**. An empty slot gets a new clip; an occupied slot is replaced. The source looper audio is kept. **WAV** still exports a numbered file separately.

Verified on Force 3.10: creation, independent native clip playback, and replacing an occupied slot. Native Undo is wired through the Force command but has not yet been verified on hardware. Arrange loop range verification is also pending. This is a Force prerelease; the MPC One+ release is unchanged.

**Install:** Catalog users select the Force effect; it requires Force Controls 0.2.5 in the same batch. For a manual install, use the complete ZIP and import both component ZIPs. The helper is a background add-in, so only one effect appears in the picker. Save the project before restarting the Force app. Back up Loops and Exports if upgrading from the old RetroLooper Force install folder.

GPL-3.0-only. The corresponding source and notices are included at this tag.
