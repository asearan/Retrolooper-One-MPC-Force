# Validation

Copyright © 2026 IAMTHEBAND LLC, Retroloop USA.

## MPC One+ release

Plugin 0.3.6 and helper 0.2.7 were exercised on MPC One+ 3.10.0.49. Hardware checks include clean loop playback/overdubs, selected-track input routing, avoiding duplicate native timeline capture, native pad colours/actions, Track Mute/Pad Mute handoff, returning looper controls, steady assignment knobs and editor-driven native track selection. The displayed effect, selected native track and pad owner matched; the MPC application remained stable.

Automated checks include sanitized Mac host/DSP tests, isolated ARM audio/ownership/monitor/controller tests, exact reverse PCM and threshold timing, native skin/schema/layout/resource audits, strict helper export checks and catalog package validation. The release archives preserve the tested production binary hashes; packaging adds metadata and notices without changing DSP code.

## Force 0.2.5 hardware preview

Force 3.10 hardware preview. Clip creation, playback and replacement verified; live native Undo and Arrange range verification pending. The production ARM library and helper passed isolated tests on Force, the sanitized host suites passed, and all 36 Force ABI guards match the pinned host.

## Limits

Two-minute maximum, one stereo loop per insert, four undo levels. Only the listed firmware images are validated. Gen2 is unsupported. Force supports Matrix clip bounce; MPC timeline placement is manual. Insert effects are printed only when placed before the looper. Catalog CPU bench metadata is not supplied; no CPU performance claim is made.
