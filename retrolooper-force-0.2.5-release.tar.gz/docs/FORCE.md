# Retrolooper One — Force build

A dedicated Akai Force build of Retrolooper One, with its own VST ID (`RlF1`), binary, native helper and installer packages.

The stereo looper retains sequence-sized allocation, a 120-second maximum, four undo levels, threshold recording, Reverse, HP/LP filters, MIDI assignments, Wave/Tape/Meter views, project recall and the same graphic style. Touchscreen buttons and physical pads control capture. Force supplies the clock and global transport.

Automatic loop length and default phase use Force's VST2 cycle start/end positions, with ÷2, ×1 and ×2 available. Global Arrange is the intended timing source. The range discrepancy reported on hardware is still under investigation. “Next bar” is an optional launch mode.

## Force controls

The matching **Retrolooper One Force Controls 0.2.5** helper provides native track ownership, selected-track input preparation, pad colours and Bounce to Clip. Opening a looper selects its Audio track. With the looper open, pressing Track Select retargets the editor and pad grid to that track's looper. This was verified on Force. The helper runs in the background. Retrolooper One is the insert effect.

The looper grid uses the **bottom two rows** while its editor is visible. P1–P8 are on the bottom row and P9–P16 are on the row above, each left to right. Play and Assign use the same square touch areas. Tap a button in Play or drag a knob vertically in Assign. Both modes were verified on the Force touchscreen. Closing the editor or entering a native mute or performance mode gives the grid back to Force.

Capture preparation uses the selected owning Audio track, switches native REC ARM off to avoid duplicate timeline recording and prepares Monitor IN. Other tracks containing Retrolooper One use Monitor OFF and keep their recorded loops playing. Put effects **before** RetroLooper to record their sound into each layer. An insert receives the signal at its position in the chain; it cannot capture later insert effects.

## Validation and supported firmware

The Force device provided for this port runs 3.10. Its exact host image is pinned by GNU build ID `154ae9752e0f3c6490912a703b0dfe4b668b343d`. Other firmware builds fail closed in the helper until separately profiled.

Passed:

- Sanitized Mac DSP/host tests for audio, timing, multipliers, threshold start, reverse, persistence, memory and multiple instances.
- Force image hash, build ID and all 36 helper code/type guards.
- Read-only live application, Project, TrackPool and AudioProgram graph checks on Force.
- Isolated ARM tests executed on Force, using fixture memory and fake ALSA for ownership, monitor/arm preparation, MIDI passthrough, pad identity, native mode handoff and RGB restoration.
- Production `.so` audio tests on Force: exact /2, x1 and x2 frame counts, clean synthetic playback, four-instance capture isolation, overdub handoff, threshold sample alignment, exact stereo Reverse, local transport and loop-present feedback.
- Native skin/schema, layout and resource audits.

**Version 0.2.5 is a hardware test build.** It includes the verified Pads layout in the folder Force looks for. Save the Force project before installing the pair and restarting the application. Existing Force testers with a legacy `RetroLooper - VST - RetroLooper Force` installation should back up their `Loops` and `Exports` before moving to the new folder.

To bounce, stop Force and tap **TO CLIP** on Looper or **Choose Clip** on Mixer. In Matrix, choose an empty or occupied Audio slot on the looper's track. Reopen that looper and tap **BOUNCE** to confirm or **CANCEL** to leave the slot as it is. The bounce renders the stored loop with its filters, level and pan. Force's native Audio clip import handles placement and Undo. If the selection changes during rendering, the bounce is canceled and the WAV remains in the plugin's `Exports` folder. The looper keeps its original recording. Use Stop Now on the looper to audition the new clip on its own.

**WAV** still exports a numbered WAV to `Exports` without changing any clip. Bounce uses separately named WAV files and does not consume a numbered slot. Native clip creation, playback and replacement were verified on Force. Live native Undo remains pending.

## Distribution and build

Share the two ZIP packages together from `releases/Force/`, following that folder's installation notes. They use the standard community catalog/plugin and addin formats. Keep them separate from `releases/MPC One+/`.

```sh
python3 build_force.py test --sanitize
python3 build_controls.py --zig /path/to/zig-0.13.0
python3 build_force.py arm --zig /path/to/zig-0.13.0
python3 build_force.py preview
python3 workspace/tools/preview_server.py --port 8766
python3 build_force.py package --kit /path/to/pinned/mpc-vst-plugins
```

Generated sources are in `workspace/`; packages are in `dist/`. `workspace/provenance.json` records source hashes and asserted adaptations. Parameter indices/order/defaults remain compatible. The main MPC preview on port 8765 is independent.

References: [community Force skin findings](https://github.com/open-mpc/mpc-vst-plugins/blob/main/docs/OS2_SKINS.md), [Force Q-Link mapping](https://github.com/open-mpc/mpc-vst-plugins/blob/main/docs/NOTES.md).
