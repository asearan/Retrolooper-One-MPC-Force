# RetroLooper One Controls (Force) 0.1.0

Matching background integration for RetroLooper One; installed automatically with the effect.

An addin for MPC OS standalone devices: a library MPC loads at its start (through `LD_PRELOAD`), not a plugin on a
track. It is installed to `/data/mpc-addins/retrolooper-force-controls/`.

## Requirements

- A Gen1 MPC OS standalone device (32-bit ARM: Force, MPC Live / Live II, One, X, Key 61 and Key 37). The installer refuses anything else.
- **Root shell access** (SSH) to the device. Stock MPC OS doesn't offer this; you need a modded unit.
- EXPERIMENTAL: Force 3.10, host build 154ae9752e0f3c6490912a703b0dfe4b668b343d. Live Arrange/audio/pad functional validation pending. Never use MPC helper packages.
- Installing addins this way is unofficial: back up first, use at your own risk.

## Install

1. Unzip, then copy the whole folder to the device, e.g. `scp -r RetroLooper-One-Controls-Force-0.1.0 root@<device-ip>:/tmp/`
2. Run it: `ssh root@<device-ip> sh /tmp/RetroLooper-One-Controls-Force-0.1.0/install.sh`

The installer copies the addin into `/data/mpc-addins/retrolooper-force-controls/`, adds `retrolooper_force_controls.so` to the `LD_PRELOAD` list of MPC's service
and **restarts MPC** (save your project first). The list is extended, never replaced: other addins and the
libraries the firmware preloads stay. Where no writable file sets the list (the unit is on the read-only root), one
drop-in shared by every addin sets it, `/etc/systemd/system/<service>.service.d/90-mpc-addins.conf`. Re-run the
installer after a firmware update. `-y` skips the question, `-n` leaves the restart to you.

Force-only test build. Opening RetroLooper One selects its owning Audio track. The lower two pad rows control that instance only while its editor is visible; native Force modes retain the full grid when it closes.

## Uninstall

`ssh root@<device-ip> sh /data/mpc-addins/retrolooper-force-controls/uninstall.sh` takes the addin out of `LD_PRELOAD`, restarts MPC and
deletes its folder.

## Files

See `SHA256SUMS`. Made with [mpc-vst-plugins](https://github.com/open-mpc/mpc-vst-plugins) (`docs/ADDINS.md`).
