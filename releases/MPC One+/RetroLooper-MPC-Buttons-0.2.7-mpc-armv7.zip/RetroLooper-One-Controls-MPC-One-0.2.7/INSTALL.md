# RetroLooper One Controls (MPC One+) 0.2.7

Matching background integration for RetroLooper One; installed automatically with the effect.

An addin for MPC OS standalone devices: a library MPC loads at its start (through `LD_PRELOAD`), not a plugin on a
track. It is installed to `/data/mpc-addins/retrolooper-buttons/`.

## Requirements

- A Gen1 MPC OS standalone device (32-bit ARM: Force, MPC Live / Live II, One, X, Key 61 and Key 37). The installer refuses anything else.
- **Root shell access** (SSH) to the device. Stock MPC OS doesn't offer this; you need a modded unit.
- MPC One+ with community plugins and modified MPC 3.10.0.49; host build bc141062ea5ea5be619d98366f423c8102574365. The matching helper is installed automatically.
- Installing addins this way is unofficial: back up first, use at your own risk.

## Install

1. Unzip, then copy the whole folder to the device, e.g. `scp -r RetroLooper-One-Controls-MPC-One-0.2.7 root@<device-ip>:/tmp/`
2. Run it: `ssh root@<device-ip> sh /tmp/RetroLooper-One-Controls-MPC-One-0.2.7/install.sh`

The installer copies the addin into `/data/mpc-addins/retrolooper-buttons/`, adds `retrolooper_buttons.so` to the `LD_PRELOAD` list of MPC's service
and **restarts MPC** (save your project first). The list is extended, never replaced: other addins and the
libraries the firmware preloads stay. Where no writable file sets the list (the unit is on the read-only root), one
drop-in shared by every addin sets it, `/etc/systemd/system/<service>.service.d/90-mpc-addins.conf`. Re-run the
installer after a firmware update. `-y` skips the question, `-n` leaves the restart to you.

Opening RetroLooper selects its owning Audio track and matching pad grid. Bank A still yields to native MPC modes; input follows the selected Audio track.

## Uninstall

`ssh root@<device-ip> sh /data/mpc-addins/retrolooper-buttons/uninstall.sh` takes the addin out of `LD_PRELOAD`, restarts MPC and
deletes its folder.

## Files

See `SHA256SUMS`. Made with [mpc-vst-plugins](https://github.com/open-mpc/mpc-vst-plugins) (`docs/ADDINS.md`).
