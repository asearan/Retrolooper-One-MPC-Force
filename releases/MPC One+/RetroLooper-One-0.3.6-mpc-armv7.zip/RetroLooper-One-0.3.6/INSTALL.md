# RetroLooper One 0.3.6

Single-track stereo audio overdubbing, host sequence sync, threshold start, reverse, filters and coloured pad controls.

A native MPC OS plugin (effect) with its own MPC screen skin, loaded by MPC's built-in plugin host.

## Requirements

- A first-generation MPC OS standalone device (32-bit ARM, like the Force, MPC Live / Live II, One, X and Key 61).
  The installer refuses anything else. Newer models are untested.
- **Root shell access** (SSH) to the device. Stock MPC OS doesn't offer this; you need a modded unit.
- Tested on MPC OS with a Force. Installing plugins this way is unofficial: back up first, use at your own risk.

## Install (scripted)

1. Unzip, then copy the whole folder to the device, e.g. `scp -r RetroLooper-One-0.3.6 root@<device-ip>:/tmp/`
2. Run it: `ssh root@<device-ip> sh /tmp/RetroLooper-One-0.3.6/install.sh`

The installer checks the device, **stops MPC** (save your project first), copies `portable/RetroLooper - VST - RetroLooper One/` (the plugin, its skin
and its data, as one folder) into `/sdcard/Synths`, backs up `MPC.settings`, adds the plugin to MPC's plugin list from the
folder's `plugin-meta.xml` and starts MPC again. Running it again upgrades in place, keeping your own files.
An older install of this plugin (the previous layout, with the `.so` in `/sdcard/vst`) is replaced, not duplicated.
`-y` skips the confirmation prompt; `-t <folder>` installs into another Synths folder (for example on a card).

Your own files go in `Loops/` inside the plugin folder (`/sdcard/Synths/RetroLooper - VST - RetroLooper One/`); the installer keeps them when you upgrade and uninstall, and moves them there from the old `/sdcard/vst` location if you had installed the plugin that way.

Then add **RetroLooper One** to a track from the plugin browser (Insert effects). Its screen appears in the plugin view,
and the Q-Links follow the page.

## Uninstall

`ssh root@<device-ip> sh /tmp/RetroLooper-One-0.3.6/uninstall.sh` removes the plugin folder and the plugin-list entry (it also stops and
restarts MPC). Projects that use the plugin will load without it. Files you added yourself are kept.

## Install by hand

1. Copy `portable/RetroLooper - VST - RetroLooper One/` to `/sdcard/Synths/RetroLooper - VST - RetroLooper One/`. It holds `retrolooper_one.so`, `plugin-meta.xml`, `version.xml`, `Plugin Skins/`
   and the data:
- `licenses/RetroLooper-GPL-3.0.txt` (data next to the plugin)
- `licenses/RetroLooper-COPYRIGHT.txt` (data next to the plugin)
- `licenses/THIRD_PARTY_NOTICES.md` (data next to the plugin)
- `README.md` (data next to the plugin)
- `licenses/mpc-vst-plugins-LICENSE` (data next to the plugin)
- `licenses/signalsmith-stretch-LICENSE.txt` (data next to the plugin)
- `licenses/signalsmith-linear-LICENSE.txt` (data next to the plugin)
- `licenses/Inter-OFL.txt` (data next to the plugin)
- `licenses/PressStart2P-OFL.txt` (data next to the plugin)
- `licenses/VT323-OFL.txt` (data next to the plugin)
2. Stop MPC: `systemctl stop acvs`. If there is no `acvs` service (`systemctl cat acvs` fails, as on some MPC OS 2.x versions and on Hakai-enabled systems), use `systemctl stop inmusic-mpc`.
3. Back up the settings file, `MPC.settings` (on a Force: `/media/az01-internal/Settings/MPC/MPC.settings`).
4. In `MPC.settings`, inside `<VALUE name="pluginList-arm"><KNOWNPLUGINS>`, add the line from `plugin-meta.xml` with
   `%payload-path%` replaced by `/sdcard/Synths`. If there is no `pluginList-arm` value yet, add one just before `</PROPERTIES>`:
   ```xml
   <VALUE name="pluginList-arm">
     <KNOWNPLUGINS>
       (the line from plugin-meta.xml)
     </KNOWNPLUGINS>
   </VALUE>
   ```
5. Start MPC: `systemctl start acvs`, or `systemctl start inmusic-mpc` if that is the service you stopped. If MPC shows default settings, restore your backup (the XML was malformed).

Edit `MPC.settings` only while MPC is stopped: MPC can save its own copy over a change made while it runs. Tools that
rebuild the whole plugin list from the plugin folders in `Synths` keep this plugin, because it is such a folder.

## Files

See `SHA256SUMS`. Made with [mpc-vst-plugins](https://github.com/open-mpc/mpc-vst-plugins).
